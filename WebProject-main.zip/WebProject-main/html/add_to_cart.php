<?php
session_start();


if (!isset($_SESSION['cart']) && isset($_COOKIE['cart'])) {
    $_SESSION['cart'] = json_decode($_COOKIE['cart'], true);
}

include 'db.php'; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['name'], $_POST['price'], $_POST['img'])) {
        $name = $_POST['name'];
        $price = (float)$_POST['price'];
        $img = $_POST['img'];
        
        $customer = $_SESSION['username'] ?? 'Guest';

        $newItem = [
            'name'  => $name,
            'price' => $price,
            'img'   => $img,
            'qty'   => 1
        ];

        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }

        $found = false;
        foreach ($_SESSION['cart'] as &$item) {
            if ($item['name'] == $name) {
                $item['qty']++;
                $found = true;
                break;
            }
        }

        if (!$found) {
            $_SESSION['cart'][] = $newItem;
        }

       
        setcookie("cart", json_encode($_SESSION['cart']), time() + 3600, "/");

        $sql = "INSERT INTO orders (customer_name, product_name, price, quantity, total_price) 
                VALUES ('$customer', '$name', '$price', 1, '$price')";
        
        if ($conn->query($sql)) {
            http_response_code(200);
            echo "success";
        } else {
            http_response_code(500);
            echo "Error: " . $conn->error;
        }
        exit();
    }
}
?>