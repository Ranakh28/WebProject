<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Return and Exchange Policy - Glowberry</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        .faq-container {
            padding: 60px 5%;
            max-width: 1200px;
            margin: 0 auto;
            min-height: 70vh;
        }

        .page-heading {
            text-align: center;
            color: var(--primary-color);
            margin-bottom: 50px;
            font-size: 2.5rem;
        }

        .faq-category-title {
            color: var(--primary-color);
            margin: 40px 0 20px 0;
            font-size: 1.4rem;
            border-left: 4px solid var(--accent-hover);
            padding-left: 15px;
            width: 100%;
        }

        .faq-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }

        .faq-item {
            background: #fff;
            border-radius: 20px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            border: 1px solid #f9f9f9;
            transition: 0.3s ease;
            overflow: hidden;
            height: fit-content;
        }

        .faq-item:hover {
            transform: translateY(-5px);
            border-color: var(--accent-hover);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
        }

        .faq-question {
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 25px;
            border: none;
            background: none;
            font-family: 'Poppins', sans-serif;
            font-size: 1rem;
            color: var(--primary-color);
            cursor: pointer;
            font-weight: 500;
            text-align: left;
        }

        .faq-question span {
            font-size: 1.2rem;
            color: var(--accent-hover);
            transition: 0.3s;
        }

        .faq-answer {
            max-height: 0;
            overflow: hidden;
            transition: all 0.3s ease-out;
            color: #666;
            font-size: 0.9rem;
            line-height: 1.6;
            padding: 0 25px;
            background-color: #fdfdfd;
        }

        .faq-item.active .faq-answer {
            max-height: 300px;
            padding: 10px 25px 25px 25px;
            border-top: 1px solid #f1f1f1;
        }

        .faq-item.active .faq-question span {
            transform: rotate(45deg);
            color: var(--primary-color);
        }

        @media (max-width: 768px) {
            .faq-grid {
                grid-template-columns: 1fr;
            }
            .page-heading {
                font-size: 1.8rem;
            }
        }
    </style>
</head>
<body>

    <?php include 'header.php';?>

    <main class="faq-container">
        <h2 class="page-heading">Return and Exchange Policy</h2>
        
        <h3 class="faq-category-title">General Policy</h3>
        <div class="faq-grid">
            <div class="faq-item">
                <button class="faq-question">What is the return period?<span>+</span></button>
                <div class="faq-answer">
                    <p>You can return or exchange any product within 7 days of receiving your order, provided it is in its original condition.</p>
                </div>
            </div>

            <div class="faq-item">
                <button class="faq-question">What are the return conditions?<span>+</span></button>
                <div class="faq-answer">
                    <p>The item must be unused, unopened, and in its original luxury packaging with all tags included.</p>
                </div>
            </div>
        </div>

        <h3 class="faq-category-title">Refunds and Exchanges</h3>
        <div class="faq-grid">
            <div class="faq-item">
                <button class="faq-question">How long does a refund take?<span>+</span></button>
                <div class="faq-answer">
                    <p>Once we receive and inspect your return, the refund will be processed to your original payment method within 5-10 business days.</p>
                </div>
            </div>

            <div class="faq-item">
                <button class="faq-question">Can I exchange makeup products?<span>+</span></button>
                <div class="faq-answer">
                    <p>For hygiene reasons, makeup and beauty products cannot be returned or exchanged once opened, unless they are defective.</p>
                </div>
            </div>
        </div>

    </main>

    <script>
        const faqQuestions = document.querySelectorAll('.faq-question');

        faqQuestions.forEach(question => {
            question.addEventListener('click', () => {
                const item = question.parentElement;
                item.classList.toggle('active');
            });
        });
    </script>

    <?php include 'footer.php';?>

</body>
</html>